===================================================================
LABORATORIUM INVESTIGASI KREDENSIAL — VM-01
===================================================================
Selamat datang di laboratorium analisis artefak.
Tugas Anda adalah menemukan artefak kredensial yang tertinggal,
mengidentifikasi algoritma hashing yang digunakan, merekayasa serangan
kata sandi, serta mengekstrak informasi rahasia dari sistem ini.

Panduan Singkat:
- Seluruh file bukti tersimpan di dalam folder 'evidence/'.
- Gunakan wordlist yang tersedia di 'wordlists/company.txt'.
- Dokumentasikan setiap jenis hash dan mode Hashcat yang sesuai.